cc.Class({
    extends: cc.Component,

    properties: {
        roomlist: cc.Node ,
        room:cc.Prefab,
        room_history:cc.Prefab,
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function () {

    },
    onCloseRoomWindow:function(){
        cc.vv.audioMgr.playSFX("doudizhu/button/anniu.mp3");
        this.node.active=false;
        
      
       
    },
    onChangeYK:function(){
        cc.vv.audioMgr.playSFX("doudizhu/button/anniu.mp3");
        cc.find("Canvas/FK/roomwindow/yk_bg").active=true;
        cc.find("Canvas/FK/roomwindow/dkjl_bg").active=false;
        this.getrooms();
    },
    onChangeDK:function(){
        cc.vv.audioMgr.playSFX("doudizhu/button/anniu.mp3");
        cc.find("Canvas/FK/roomwindow/yk_bg").active=false;
        cc.find("Canvas/FK/roomwindow/dkjl_bg").active=true;
        this.getrooms_history();        
    },
    getrooms:function(){
       // cc.vv.userMgr.userId
       this.roomlist.removeAllChildren();
       var self = this;
       var onGet = function(ret){
        if(ret.errcode !== 0){
            console.log(ret.errmsg);
        }
        else{
                console.log(ret.rooms);
                //房间列表
                for(var i in ret.rooms){
                    var gamename="";
                    var json_str=JSON.parse(ret.rooms[i].base_info);
                    if(json_str.type=="fangkadoudizhu")
                        gamename="斗地主";
                  
                    var renwu=0;
                 
                        if(ret.rooms[i].user_id0>0)
                            renwu++;
                        if(ret.rooms[i].user_id1>0)
                            renwu++;
                        if(ret.rooms[i].user_id2>0)
                            renwu++;
                        if(ret.rooms[i].user_id3>0)
                            renwu++;

                    
                    var game_renshu=renwu+"/"+json_str.renshu+"人";
                    var rs = json_str.renshu;
                    var gamestate=ret.rooms[i].num_of_turns>0?"已开始":"未开始";
                    var time="";//12:30:30
                    var seats=[];
                    seats.push({id:ret.rooms[i].user_id0,name:ret.rooms[i].user_name0});
                    seats.push({id:ret.rooms[i].user_id1,name:ret.rooms[i].user_name1});
                    seats.push({id:ret.rooms[i].user_id2,name:ret.rooms[i].user_name2});
                    seats.push({id:ret.rooms[i].user_id3,name:ret.rooms[i].user_name3});
                    
                    var room   = cc.instantiate(self.room);
                    var  roomConf="";
                    roomConf+=json_str.maxGames + "局";
                    if (json_str.fanshu == 999999 || json_str.fanshu == "999999"){
                        roomConf+=" 无封顶";
                    } else {
                        roomConf+=" "+json_str.fanshu+"番封顶";
                    }
                    if (json_str.jinyan == true) {
                        roomConf+=" 禁言";
                    }
                    if(rs==2){
                       if (json_str.jiabei == true) {
                           roomConf+=" 可加倍";
                       } else {
                           roomConf+=" 无加倍";
                       } 
                    }else{
                       if (json_str.jiabei3 == 0) {
                           roomConf+=" 自由加倍";
                       } else if(json_str.jiabei3 == 1){
                           roomConf+=" 农民先加倍";
                       } else{
                           roomConf+=" 不限加倍";
                       }
                       if(json_str.jiaopai==0){
                           roomConf+=" 随机叫牌";
                       }else{
                           roomConf+=" 先出完先叫牌";
                       }
                       if(json_str.GPS){
                           roomConf+=" GPS测距";
                       }
                       if(json_str.bijiao){
                           roomConf+=" 两王四个二必叫地主";
                       }
                    }

                
                    room.getComponent("room").init(ret.rooms[i].id,gamename,time,game_renshu,gamestate,seats,rs,roomConf);//id,name,time,renshu,state
                    room.parent = self.roomlist;
                }
            }
        };
        var data = {
            account:cc.vv.userMgr.account,
            sign:cc.vv.userMgr.sign,
        };
        cc.vv.http.sendRequest("/get_room_list",data,onGet);
    },
    getrooms_history:function(){
        // cc.vv.userMgr.userId
        this.roomlist.removeAllChildren();
        var self = this;
        var onGet = function(ret){
         if(ret.errcode !== 0){
             console.log(ret.errmsg);
         }
         else{
                 console.log(ret.rooms);
                 //房间列表
                    var gamename="";
                    var json_str=JSON.parse(ret.rooms[0].daikai_history);
                    for(var j=0;j<json_str.length;j++){
                        if(json_str.type=="fangkadoudizhu")
                        gamename="斗地主";                    
                        var game_renshu=json_str[j].renshu+"人";
                        var rs = json_str[j].renshu;
                        var seats = json_str[j].seats;
                        //  var gamestate=ret.rooms[i].num_of_turns>0?"已开始":"未开始";
                        var time= self.dateFormat(json_str[j].time * 1000);//12:30:30
                        var room   = cc.instantiate(self.room_history);
                        var  roomConf="";
                         roomConf+=json_str[j].conf.maxGames + "局";
                         if (json_str[j].conf.fanshu == 999999 || json_str[j].conf.fanshu == "999999"){
                             roomConf+=" 无封顶";
                         } else {
                             roomConf+=" "+json_str[j].conf.fanshu+"番封顶";
                         }
                         if (json_str[j].conf.jinyan == true) {
                             roomConf+=" 禁言";
                         }
                         if(rs==2){
                            if (json_str[j].conf.jiabei == true) {
                                roomConf+=" 可加倍";
                            } else {
                                roomConf+=" 无加倍";
                            } 
                         }else{
                            if (json_str[j].conf.jiabei3 == 0) {
                                roomConf+=" 自由加倍";
                            } else if(json_str[j].conf.jiabei3 == 1){
                                roomConf+=" 农民先加倍";
                            } else{
                                roomConf+=" 不限加倍";
                            }
                            if(json_str[j].conf.jiaopai==0){
                                roomConf+=" 随机叫牌";
                            }else{
                                roomConf+=" 先出完先叫牌";
                            }
                            if(json_str[j].conf.GPS){
                                roomConf+=" GPS测距";
                            }
                            if(json_str[j].conf.bijiao){
                                roomConf+=" 两王四个二必叫地主";
                            }
                         }
                                        
                        room.getComponent("room_history").init(json_str[j].id,gamename,time,game_renshu,"",seats,rs,roomConf);//id,name,time,renshu,state
                        room.parent = self.roomlist;
                    }
                    
                    
             }
         };
         var data = {
             account:cc.vv.userMgr.account,
             sign:cc.vv.userMgr.sign,
         };
         cc.vv.http.sendRequest("/get_room_history_list",data,onGet);
     },
     dateFormat:function(time){
        var date = new Date(time);
        var datetime = "{0}-{1}-{2} {3}:{4}:{5}";
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        month = month >= 10? month : ("0"+month);
        var day = date.getDate();
        day = day >= 10? day : ("0"+day);
        var h = date.getHours();
        h = h >= 10? h : ("0"+h);
        var m = date.getMinutes();
        m = m >= 10? m : ("0"+m);
        var s = date.getSeconds();
        s = s >= 10? s : ("0"+s);
        datetime = datetime.format(year,month,day,h,m,s);
        return datetime;
    },
});
