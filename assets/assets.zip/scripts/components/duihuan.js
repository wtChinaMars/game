// Learn cc.Class:
//  - [Chinese] http://www.cocos.com/docs/creator/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/editors_and_tools/creator-chapters/scripting/class/index.html
// Learn Attribute:
//  - [Chinese] http://www.cocos.com/docs/creator/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/editors_and_tools/creator-chapters/scripting/reference/attributes/index.html
// Learn life-cycle callbacks:
//  - [Chinese] http://www.cocos.com/docs/creator/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/editors_and_tools/creator-chapters/scripting/life-cycle-callbacks/index.html

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },
        _zs:0,
        _jb:0,
        _jt:0,
        _showDaoju:"",
        lblNotice:cc.Label,
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad :function() {
        var beibaoinfo = JSON.parse(cc.vv.userMgr.beibao_info);
        var zs_num=0;
        for(var i=0;i<beibaoinfo.wupin.length;i++){
            if(beibaoinfo.wupin[i].name=="zs"){
                zs_num=beibaoinfo.wupin[i].sum;
            }
        }
        this.lblNotice.string = cc.vv.userMgr.notice.msg;
        cc.find("Canvas/duihuan/zs/lbl_ZS").getComponent(cc.Label).string=zs_num;
        this._zs=zs_num;
        cc.find("Canvas/duihuan/jt/lbl_JT").getComponent(cc.Label).string=cc.vv.userMgr.jintiao;
        this._jt=cc.vv.userMgr.jintiao;
        cc.find("Canvas/duihuan/jb/lbl_JB").getComponent(cc.Label).string=cc.vv.userMgr.coins;
        this._jb=cc.vv.userMgr.coins;
    },

    start () {

    },
    onClicked:function(event){
        if(event.target.name=="hfka"||event.target.name=="llka"){
            var daoju = cc.find("Canvas/duihuan/xnlist/view/content").getChildByName(event.target.name);
            var name =  daoju.getChildByName("name").getComponent(cc.Label).string;
            cc.find("Canvas/duihuan/drdd/dingdan/name").getComponent(cc.Label).string=name;
            var buy =  daoju.getChildByName("buy").getComponent(cc.Label).string;
            cc.find("Canvas/duihuan/drdd/dingdan/buy").getComponent(cc.Label).string=buy;
            var pageurl = cc.url.raw("resources/textures/beibao/daoju/"+event.target.name+".png");
            var textures = cc.textureCache.addImage(pageurl);
            cc.find("Canvas/duihuan/drdd/dingdan/sprite").getComponent(cc.Sprite).spriteFrame.setTexture(textures);
            cc.find("Canvas/duihuan/drdd").active=true;
            this._showDaoju=event.target.name;
        }else{
            var daoju = cc.find("Canvas/duihuan/xnlist/view/content").getChildByName(event.target.name);
            var name =  daoju.getChildByName("name").getComponent(cc.Label).string;
            cc.find("Canvas/duihuan/qrdh/layout/name").getComponent(cc.Label).string=name;
            var buy =  daoju.getChildByName("buy").getComponent(cc.Label).string;
            cc.find("Canvas/duihuan/qrdh/layout/money").getComponent(cc.Label).string=buy;
            cc.find("Canvas/duihuan/qrdh").active=true;
            this._showDaoju=event.target.name;
        }
        

    },
    onClicked_duiHuan:function(){
        var daoju = cc.find("Canvas/duihuan/xnlist/view/content").getChildByName(this._showDaoju);
        var num =  daoju.getChildByName("num").getComponent(cc.Label).string;
        var type =  daoju.getChildByName("type").getComponent(cc.Label).string;
        var name = cc.find("Canvas/duihuan/drdd/editbox/name").getComponent(cc.EditBox).string;
        var phone = cc.find("Canvas/duihuan/drdd/editbox/phone").getComponent(cc.EditBox).string;
        var address = cc.find("Canvas/duihuan/drdd/editbox/address").getComponent(cc.EditBox).string;
        var beizhu = cc.find("Canvas/duihuan/drdd/editbox/beizhu").getComponent(cc.EditBox).string;
        var daoju = cc.find("Canvas/duihuan/drdd/dingdan/name").getComponent(cc.Label).string;
        if(type=="zs"){
            if(num>this._zs){
                cc.vv.alert.show("提示","钻石不足,无法兑换！");
            }else{
                this.duihuandingdan(num,type,name,phone,address,beizhu,daoju);
            }
        }else if(type=="jb"){
            if(num>this._jb){
                cc.vv.alert.show("提示","金币不足,无法兑换！");
            }else{
                this.duihuandingdan(num,type,name,phone,address,beizhu,daoju);
            }
        }else if(type=="jt"){
            if(num>this._jt){
                cc.vv.alert.show("提示","金条不足,无法兑换！");
            }else{
                this.duihuandingdan(num,type,name,phone,address,beizhu,daoju);
            }
        }
    },
    onClicked_duiHuan1:function(){
        var daoju = cc.find("Canvas/duihuan/xnlist/view/content").getChildByName(this._showDaoju);
        var num =  daoju.getChildByName("num").getComponent(cc.Label).string;
        var type =  daoju.getChildByName("type").getComponent(cc.Label).string;
        var name = this._showDaoju;
        if(type=="zs"){
            if(num>this._zs){
                cc.vv.alert.show("提示","钻石不足,无法兑换！");
            }else{
                this.duihuandingdan1(num,type,name);
            }
        }else if(type=="jb"){
            if(num>this._jb){
                cc.vv.alert.show("提示","金币不足,无法兑换！");
            }else{
                this.duihuandingdan1(num,type,name);
            }
        }else if(type=="jt"){
            if(num>this._jt){
                cc.vv.alert.show("提示","金条不足,无法兑换！");
            }else{
                this.duihuandingdan1(num,type,name);
            }
        }
    },
    onClose:function(){
        cc.find("Canvas/duihuan/drdd").active=false;   
        cc.find("Canvas/duihuan/qrdh").active=false;   
    },
    duihuandingdan:function(num,type,name,phone,address,beizhu,daoju){
        if(name&&phone&&address&&beizhu){
            var data = {
                userid:cc.vv.userMgr.userId,
                name:name,
                phone:phone,
                address:address,
                beizhu:beizhu,
                num:num,
                type:type,
                daoju:daoju,
            }
            var self = this;
            var onCreate = function (ret) {
                if (ret.errcode !== 0) {
                    console.log(ret.errmsg);
                }
                else {
                    cc.vv.alert.show("提示","兑换成功!");
                }
            };
            cc.vv.http.sendRequest("/duihuan", data, onCreate);
        }else{
            cc.vv.alert.show("提示","列表不能为空!");
        }
    },
    duihuandingdan1:function(num,type,name){
        var data = {
            userid:cc.vv.userMgr.userId,
            name:name,
            num:num,
            type:type,
        }
        var self = this;
        var onCreate = function (ret) {
            if (ret.errcode !== 0) {
                console.log(ret.errmsg);
            }
            else {
                cc.vv.alert.show("提示","兑换成功!");
            }
        };
        cc.vv.http.sendRequest("/duihuan1", data, onCreate);
    },
    update : function (dt) {
        var x = this.lblNotice.node.x;
        x -= dt * 100;
        if (x + this.lblNotice.node.width < -1000) {
            x = 500;
        }
        this.lblNotice.node.x = x;

        if (cc.vv && cc.vv.userMgr.roomData != null) {
            cc.vv.userMgr.enterRoom(cc.vv.userMgr.roomData);
            cc.vv.userMgr.roomData = null;
        }
    },
});




