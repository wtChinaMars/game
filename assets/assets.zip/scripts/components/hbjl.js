// Learn cc.Class:
//  - [Chinese] http://www.cocos.com/docs/creator/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/editors_and_tools/creator-chapters/scripting/class/index.html
// Learn Attribute:
//  - [Chinese] http://www.cocos.com/docs/creator/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/editors_and_tools/creator-chapters/scripting/reference/attributes/index.html
// Learn life-cycle callbacks:
//  - [Chinese] http://www.cocos.com/docs/creator/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/editors_and_tools/creator-chapters/scripting/life-cycle-callbacks/index.html

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },
        item:cc.Prefab,
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad:function () {
        this.getItem();
    },

    start () {

    },
    getItem:function(){
        var data={
            userid:cc.vv.userMgr.userId,
        }
        var self = this;
        var onCreate = function (ret) {
            if (ret.errcode !== 0) {
                console.log(ret.errmsg);
            }
            else {
                cc.vv.wc.hide();
                var rets=ret.ret;
           //   rets=JSON.stringify(ret.ret);
                for(var i=0;i<rets.user.length;i++){
                    var daili = cc.instantiate(self.item);
                    var cdk = rets.user[i].kouling;
                    var money = rets.user[i].money;
                    var create_time = rets.user[i].time;
                    var state = rets.user[i].count;
                    cc.find("Canvas/hbjl/viewlist/view/content").addChild(daili);
                    daili.getChildByName("cdk").getComponent(cc.Label).string=cdk;
                    daili.getChildByName("money").getComponent(cc.Label).string=money;
                    daili.getChildByName("create_time").getComponent(cc.Label).string=create_time;
                    daili.getChildByName("state").getComponent(cc.Label).string=state==1?"未使用":"已使用";
                }
            }
        };
        cc.vv.wc.show("nuli chazhaozhong ");
        cc.vv.http.sendRequest("/select_hbjl", data, onCreate);

    },
    onClickClose:function(){
        cc.find("Canvas/hbjl").active=false;
    },
    // update (dt) {}, 
});
