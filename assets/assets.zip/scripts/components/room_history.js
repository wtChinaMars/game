cc.Class({
    extends: cc.Component,

    properties: {
        share:cc.Node,
        g_id:cc.Label,
        g_name:cc.Label,
        g_time:cc.Label,
        g_renshu:cc.Label,
        g_state:cc.Label,
        g_wanfa:cc.Label,
        useats:{
            default:[],
            type:cc.Node
        },
        _roomid:null,
        _renshu:null,
        _roomConf:null,
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function () {

    },
    init:function(id,name,time,renshu,state,seats,rs,roomConf){
        this._roomid=id;
        this.g_id.string="房间号"+id;
        this.g_name.string=name;
        this.g_time.string=time;
        this.g_renshu.string=renshu;
        console.log(time);
        // this.g_state.string=state;
        this.g_wanfa.string=roomConf;
        if(rs==2){
            this.useats[2].active=false;
        }else{
            this.useats[2].active=true;
            
        }
        this._renshu=rs;
        this._roomConf=roomConf;
        for(i=0;i<seats.length;i++){
            var u_name=  this.useats[i].getChildByName("name");
            var u_score=  this.useats[i].getChildByName("score");
            u_name.getComponent(cc.Label).string=this.decode(seats[i].name);
            u_score.getComponent(cc.Label).string=seats[i].score;
            var sss=  this.useats[i].getChildByName("icon");
            var head=sss.getComponent("ImageLoader");
            head.setUserID(seats[i].userid);
        }
    },
 
    onClickShare:function(event){
        if(this._renshu==2){
            cc.vv.anysdkMgr.share("豆乐棋牌-二人斗地主！" ,"房号:" +this._roomid+ " 玩法:" + this._roomConf);
        }else{
            cc.vv.anysdkMgr.share("豆乐棋牌-三人斗地主！" ,"房号:" + this._roomid + " 玩法:" + this._roomConf);
        }
    },
    decode: function decode(input) {
        var output = "";
        var chr1, chr2, chr3;
        var enc1, enc2, enc3, enc4;
        var i = 0;
        input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
        var _keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
        while (i < input.length) {
            enc1 = _keyStr.indexOf(input.charAt(i++));
            enc2 = _keyStr.indexOf(input.charAt(i++));
            enc3 = _keyStr.indexOf(input.charAt(i++));
            enc4 = _keyStr.indexOf(input.charAt(i++));
            chr1 = enc1 << 2 | enc2 >> 4;
            chr2 = (enc2 & 15) << 4 | enc3 >> 2;
            chr3 = (enc3 & 3) << 6 | enc4;
            output = output + String.fromCharCode(chr1);
            if (enc3 != 64) {
                output = output + String.fromCharCode(chr2);
            }
            if (enc4 != 64) {
                output = output + String.fromCharCode(chr3);
            }
        }
        var string = "";
        var i = 0;
        var c = 0,
            c1 = 0,
            c2 = 0,
            c3 = 0;
        while (i < output.length) {
            c = output.charCodeAt(i);
            if (c < 128) {
                string += String.fromCharCode(c);
                i++;
            } else if (c > 191 && c < 224) {
                c2 = output.charCodeAt(i + 1);
                string += String.fromCharCode((c & 31) << 6 | c2 & 63);
                i += 2;
            } else {
                c2 = output.charCodeAt(i + 1);
                c3 = output.charCodeAt(i + 2);
                string += String.fromCharCode((c & 15) << 12 | (c2 & 63) << 6 | c3 & 63);
                i += 3;
            }
        }
        return string;
    },
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
