cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        jb_title:cc.Node,
        jt_title:cc.Node,
        jb_page:cc.Node,
        jt_page:cc.Node,
        lblJT:cc.Label,
        lblJB:cc.Label,
        lblFK:cc.Label,
        shopping:cc.Node,
        _paycount:0,
        _type:"",
        _value:0 ,            
        _title:"",
        _jtzf:0,

    },

    // use this for initialization
    onLoad: function () {
        this.lblJB.string = cc.vv.userMgr.coins;
        this.lblJT.string = cc.vv.userMgr.jintiao;
        this.lblFK.string = cc.vv.userMgr.gems;
        //判断是否存在首冲
        this.isShouchong();

        
    },
//onclick
    onClicked: function(event){
        if(event.target.name=="btn_JT"){
            cc.vv.audioMgr.playSFX("doudizhu/button/anniu.mp3");
            this.jt_title.active=true;
            this.jt_page.active=true;
            this.jb_title.active=false;
            this.jb_page.active=false;

        }
    },
    onClicked1: function(event){
        if(event.target.name=="btn_JB"){
            cc.vv.audioMgr.playSFX("doudizhu/button/anniu.mp3");
            this.jb_title.active=true;
            this.jb_page.active=true;
            this.jt_title.active=false;
            this.jt_page.active=false;
        }
    },
    onClickClose: function(event){
        if(event.target.name="btn_shopClose"){
            this.shopping.active=false;
        }
    },
    onClickedPay: function(event){
        var paycount = 0;
        var type = "";
        var title="";
        var value = 0;
        var jtzf = 0;
        if(event.target.name == "liuwanjb"){
            paycount = 6;
            title="6万金币";
            type = "coins";
            value = 60000;   
            jtzf=60;         
        }else if(event.target.name == "shierjinbi"){
            paycount = 12;
            type = "coins";
            value = 120000;            
            title="12万金币";
            jtzf=120;         
        }else if(event.target.name == "sanshijinbi"){
            paycount = 30;
            type = "coins";
            value = 300000;            
            title="30万金币";
            jtzf=300;  
        }else if(event.target.name == "sishibajinb"){
            paycount = 48;
            type = "coins";
            value = 480000;            
            title="48万金币";
            jtzf=480;  
        }else if(event.target.name == "jiushiliu"){
            paycount = 96;
            type = "coins";
            value = 960000;            
            title="96万金币";
            jtzf=960;  
        }else if(event.target.name == "yibaijiushiba"){
            paycount = 198;
            type = "coins";
            value = 1980000;            
            title="198万金币";
            jtzf=1980;
        }
        
        else if(event.target.name == "liujintiao"){
            paycount = 6;
            type = "jintiao";
            value = 60;            
            title="60根金条";
        }else if(event.target.name == "shierjintiao"){
            paycount = 12;
            type = "jintiao";
            value = 120;            
            title="120根金条";
        }else if(event.target.name == "sanshijintiao"){
            paycount = 30;
            type = "jintiao";
            value = 300;            
            title="300根金条";
        }else if(event.target.name == "sishibajintiao"){
            paycount = 48;
            type = "jintiao";
            value = 500;            
            title="500根金条";
        }else if(event.target.name == "jiushiliujintiao"){
            paycount = 96;
            type = "jintiao";
            value = 980;            
            title="980根金条";
        }else if(event.target.name == "yaoshi"){
            paycount = 6;
            value = 1;            
            type = "gems";
            title="一把钥匙";
        }
        if(paycount!=0){
            // cc.vv.alert.show("提示",paycount);(userid,title,type,value,money){
            this.changeZhiFu(title,type,value,paycount,jtzf);
        }else{
            cc.vv.alert.show("提示","未知错误!")
        }
    },
    isShouchong :function (){
        var data = {
            userid:cc.vv.userMgr.userId,
        }
        var self = this;
        var onCreate = function (ret) {
            if (ret.errcode !== 0) {
                console.log(ret.errmsg);
            }
            else {
                cc.find("Canvas/shopping/jb_page/scjb").active=true;
            }
        };
        cc.vv.http.sendRequest("/isjbshouchong", data, onCreate);
        var data = {
            userid:cc.vv.userMgr.userId,
        }
        var self = this;
        var onCreate = function (ret) {
            if (ret.errcode !== 0) {
                console.log(ret.errmsg);
            }
            else {
                cc.find("Canvas/shopping/jt_page/scjt").active=true;
            }
        };
        cc.vv.http.sendRequest("/isjtshouchong", data, onCreate);
    },
    changeZhiFu:function(title,type,value,paycount,jtzf){
        if(cc.sys.os == cc.sys.OS_ANDROID){
            cc.find("Canvas/shopping/zffs").active=true;
            cc.find("Canvas/shopping/zffs/name").getComponent(cc.Label).string=title;
            cc.find("Canvas/shopping/zffs/money").getComponent(cc.Label).string=paycount+"元";
            if(jtzf==0){
                cc.find("Canvas/shopping/zffs/jtzhifu").active=false;
            }else{
                cc.find("Canvas/shopping/zffs/jtzhifu/money").getComponent(cc.Label).string=jtzf;
                cc.find("Canvas/shopping/zffs/jtzhifu").active=false;
            }
            this._paycount =paycount;
            this._type = type;
            this._value =value;            
            this._title=title;
            this._jtzf=jtzf;
        }          
        else if(cc.sys.os == cc.sys.OS_IOS){

        }
        
        
    },
    onClose(){
        cc.find("Canvas/shopping/zffs").active=false;
    },
    onWXPay(){
        cc.vv.anysdkMgr.WXPay(this._title,this._type,cc.vv.userMgr.userId,this._value,this._paycount);
    },
    onZFBPay(){
        cc.vv.anysdkMgr.AliPay(this._title,this._type,cc.vv.userMgr.userId,this._value,this._paycount);
    },
    onJTPay(){
        if(cc.vv.userMgr.jintiao<this._jtzf){
            cc.vv.alert.show("支付失败","金条不足!");
        }else{
            var data = {
                userid:cc.vv.userMgr.userId,
                title:this._title,
                type:this._type,
                value:this._value,
                jtzf:this._jtzf,
            }
            var self = this;
            var onCreate = function (ret) {
                if (ret.errcode !== 0) {
                    console.log(ret.errmsg);
                    cc.vv.alert.show("支付失败","支付未完成!");
                }
                else {
                    cc.vv.alert.show("提示","购买成功!");
                }
            };
            cc.vv.http.sendRequest("/jthjb", data, onCreate);
        }
        
    },    
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
