// Learn cc.Class:
//  - [Chinese] http://www.cocos.com/docs/creator/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/editors_and_tools/creator-chapters/scripting/class/index.html
// Learn Attribute:
//  - [Chinese] http://www.cocos.com/docs/creator/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/editors_and_tools/creator-chapters/scripting/reference/attributes/index.html
// Learn life-cycle callbacks:
//  - [Chinese] http://www.cocos.com/docs/creator/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/editors_and_tools/creator-chapters/scripting/life-cycle-callbacks/index.html

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },
        _money:25,
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {

    },
    onBtnClicked:function(){
        var beibao = JSON.parse(cc.vv.userMgr.beibao_info);
        for(var i=0;i<beibao.wupin.length;i++){
            if(beibao.wupin[i].name=="pthongbao"){
                if(Math.floor(beibao.wupin[i].sum)>=this._money){
                    var data = {
                        money:this._money,
                        userid:cc.vv.userMgr.userId,
                    }
                    var self = this;
                    var onCreate = function (ret) {
                        if (ret.errcode !== 0) {
                            console.log(ret.errmsg);
                        }
                        else {
                        }
                    };
                    cc.vv.http.sendRequest("/hongbaotx", data, onCreate);
                }else{
                    cc.vv.alert.show("提示","累计红包不足提现金额!");
                }

            }
        }
        
    },
    onBtnClose:function(){
        cc.find("Canvas/hongbaotx").active=false;
    },
    onBtnHBJL:function(){
        cc.find("Canvas/hbjl").active=true;
    },
    onBtnCheck:function(event){
        if(event.target.name=="yuan25"){
            cc.find("Canvas/hongbaotx/yuan25/createroom_check").active=true;
            cc.find("Canvas/hongbaotx/yuan50/createroom_check").active=false;
            this._money=25;
        }else{
            cc.find("Canvas/hongbaotx/yuan25/createroom_check").active=false;
            cc.find("Canvas/hongbaotx/yuan50/createroom_check").active=true;
            this._money=50;
        }
    },
    // update (dt) {},
});
