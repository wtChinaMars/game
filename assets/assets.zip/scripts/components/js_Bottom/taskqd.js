cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        datelayOut: cc.Node,
        jindutiao: cc.Node,
        yiqiandao: cc.Node,
        bqcount: cc.Label,
        _date:[],
        _bqka:0,
    },

    // use this for initialization
    onLoad: function () {
        //0未签到 1已签到 2 补签到
        this.getDate();
        var beibao = cc.vv.userMgr.beibao_info;
        beibao = JSON.parse(beibao);
        for(var i=0;i<beibao.wupin.length;i++){
            if(beibao.wupin[i].name=="bqka"){
                this._bqka = beibao.wupin[i].sum;
            }
        }
        
        
        // this.showTime(arry);
    },
//onclick
    onClicked: function(event){
        if(event.target.name=="btn_qd"){
            // this.getQiandao();
            var date = new Date();
            var today = date.getDate();
            var data = {
                userid:cc.vv.userMgr.userId,
                today:today,
            }
            var self = this;
            var onCreate = function (ret) {
                if (ret.errcode !== 0) {
                    console.log(ret.errmsg);
                }
                else {
                    console.log(ret);
                    self.getDate();
                    self.yiqiandao.active=true;
                }
            };
            cc.vv.http.sendRequest("/doqiandao", data, onCreate);
        }
    },
    onClicked1: function(event){
        
        if(this._bqka==0){
            cc.vv.alert.show("提示","补签卡不足!");
        }else{
            if(event.target.name=="btn_bq"){
                var data = {
                    userid:cc.vv.userMgr.userId,
                }
                var self = this;
                var onCreate = function (ret) {
                    if (ret.errcode !== 0) {
                        console.log(ret.errmsg);
                        cc.vv.alert.show("提示","无法补签!");
                    }
                    else {
                        console.log(ret);
                        self.getDate();
                        self.bqcount.string="补签("+(this.bqka-1)+")";
                        cc.vv.alert.show("提示","补签成功!");
                    }
                };
                cc.vv.http.sendRequest("/dobuqian", data, onCreate);
               
           }
        }
        
    },
//function
    showTime:function(arry){
        var startDate = new Date();
        var count = 0;
        var today = startDate.getDate();
        //是否可签到
        if(arry[today-1]==0){
            this.yiqiandao.active=false;
        }else{
            this.yiqiandao.active=true;
        }
        this.bqcount.string="补签("+this._bqka+")";
        for (var i=0;i<42;i++){
            if(startDate.getDay()==i){
                for(var j = 0; j<this.getMaxDay(startDate.getMonth(),startDate.getFullYear()) ; j++){
                    if(arry[j]==0){
                        this.datelayOut.getChildByName("day"+i).getChildByName("lbldate").getComponent(cc.Label).string=j+1;
                        this.datelayOut.getChildByName("day"+i).getChildByName("lbldate").active=true;
                        this.datelayOut.getChildByName("day"+i).getChildByName("bu").active=false;
                        this.datelayOut.getChildByName("day"+i).getChildByName("duihao").active=false;
                    }else if(arry[j]==1){
                        this.datelayOut.getChildByName("day"+i).getChildByName("lbldate").getComponent(cc.Label).string=j+1;
                        this.datelayOut.getChildByName("day"+i).getChildByName("lbldate").active=false;
                        this.datelayOut.getChildByName("day"+i).getChildByName("bu").active=false;
                        this.datelayOut.getChildByName("day"+i).getChildByName("duihao").active=true;
                        count+=1;
                    }else if(arry[j]==2){
                        this.datelayOut.getChildByName("day"+i).getChildByName("lbldate").getComponent(cc.Label).string=j+1;
                        this.datelayOut.getChildByName("day"+i).getChildByName("bu").active=true;
                        this.datelayOut.getChildByName("day"+i).getChildByName("lbldate").active=false;
                        this.datelayOut.getChildByName("day"+i).getChildByName("duihao").active=false;
                        count+=1;
                    }
                    if(j!=this.getMaxDay(startDate.getMonth(),startDate.getFullYear())-1){
                        i++;                    
                    }
                    console.log("j"+j+"i"+i);
                    
                }
                
            }else{
                this.datelayOut.getChildByName("day"+i).getChildByName("bu").active=false;
                this.datelayOut.getChildByName("day"+i).getChildByName("duihao").active=false;
                this.datelayOut.getChildByName("day"+i).getChildByName("lbldate").active=false;
            }
            
        }
        // Canvas/bottom/task/meiriqiandao/jindutiao
        this.jindutiao.getChildByName("jindutiao").width=630*(count/this.getMaxDay(startDate.getMonth(),startDate.getFullYear()));
    },
    getMaxDay: function (month,year){
        var d = new Date(year, month, 0);
        return d.getDate();
   },
   getQianDao: function(){

   },
   getBuQian: function(){
    
   },
   getDate: function(){
        var data = {
            userid:cc.vv.userMgr.userId,
        }
        var self = this;
        var onCreate = function (ret) {
            if (ret.errcode !== 0) {
                console.log(ret.errmsg);
            }
            else {
                console.log(ret);
                self.showTime(ret.ret[0].day);
            }
        };
        cc.vv.http.sendRequest("/getqiandao", data, onCreate);
    },
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
