// Learn cc.Class:
//  - [Chinese] http://www.cocos.com/docs/creator/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/editors_and_tools/creator-chapters/scripting/class/index.html
// Learn Attribute:
//  - [Chinese] http://www.cocos.com/docs/creator/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/editors_and_tools/creator-chapters/scripting/reference/attributes/index.html
// Learn life-cycle callbacks:
//  - [Chinese] http://www.cocos.com/docs/creator/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/editors_and_tools/creator-chapters/scripting/life-cycle-callbacks/index.html

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },
        daoju:cc.Prefab,
    },

    // LIFE-CYCLE CALLBACKS:

     onLoad :function() {
         if(this.daoju)
         this.init();
        
     },

    init :function() {
        var data = {
            userid: cc.vv.userMgr.userId,
        }

        var self = this;
        var onCreate = function (ret) {
            if (ret.errcode !== 0) {
                console.log(ret.errmsg);
            }
            else {
                
                for(var i=0;i<ret.str.wupin.length;i++){
                    var pre = cc.instantiate(self.daoju);
                    cc.find("Canvas/beibao/beibaoinfo/view/content").addChild(pre);
                    var dj = pre.getChildByName("daoju").getChildByName(ret.str.wupin[i].name);
                    dj.getChildByName("num").getComponent(cc.Label).string=ret.str.wupin[i].sum;
                    dj.active=true;
                    cc.find("Canvas/beibao/ccg_bg/xd_jb").getComponent(cc.Label).string=cc.vv.userMgr.coins;
                    cc.find("Canvas/beibao/ccg_bg/cc_jb").getComponent(cc.Label).string=ret.str.c_coins;
                }
            }
        };
        cc.vv.http.sendRequest("/beibaoinfo", data, onCreate);
        
    },
    onClickedShowDJ:function(event){
        var data = {
            daoju: event.target.name,
        }
        var dj=event.target.getChildByName("num").getComponent(cc.Label).string;
        var self = this;
        var onCreate = function (ret) {
            if (ret.errcode !== 0) {
                console.log(ret.errmsg);
            }
            else {
                var pageurl = cc.url.raw("resources/textures/beibao/daoju/"+ret.ret[0].wupininfo+".png");
                var textures = cc.textureCache.addImage(pageurl);
                cc.find("Canvas/beibao/xiangxi_bg/wupin_bg/sprite").getComponent(cc.Sprite).spriteFrame.setTexture(textures);
                cc.find("Canvas/beibao/xiangxi_bg/name").getComponent(cc.Label).string=ret.ret[0].name;
                cc.find("Canvas/beibao/xiangxi_bg/gnms").getComponent(cc.Label).string=ret.ret[0].type;
                cc.find("Canvas/beibao/xiangxi_bg/wply").getComponent(cc.Label).string=ret.ret[0].info;
                cc.find("Canvas/beibao/xiangxi_bg/num").getComponent(cc.Label).string=dj;
                cc.find("Canvas/beibao/xiangxi_bg/danwei").getComponent(cc.Label).string=ret.ret[0].danwei;
                cc.find("Canvas/beibao/xiangxi_bg/btn_duihuan/label").getComponent(cc.Label).string=ret.ret[0].btn
                cc.find("Canvas/beibao/xiangxi_bg").active=true;


            }
        };
        cc.vv.http.sendRequest("/daojuinfo", data, onCreate);
        
    },
    onClose:function(){
        cc.find("Canvas/beibao/xiangxi_bg").active=false;
    },
    onSlided:function(slider){
        if(slider.node.parent.name == "cunru"){
            var xd = cc.find("Canvas/beibao/ccg_bg/xd_jb").getComponent(cc.Label).string;
            cc.find("Canvas/beibao/input_cunru").getComponent(cc.EditBox).string=Math.floor(xd*slider.progress);
            cc.find("Canvas/beibao/cunru/progress/progress/setting12").width=300*slider.progress;
        }
        else if(slider.node.parent.name == "quchu"){
            var xd = cc.find("Canvas/beibao/ccg_bg/cc_jb").getComponent(cc.Label).string;
            cc.find("Canvas/beibao/input_quchu").getComponent(cc.EditBox).string=Math.floor(xd*slider.progress);
            cc.find("Canvas/beibao/quchu/progress/progress/setting12").width=300*slider.progress;
            
        }
    },
    onClickedCun:function(){
        var cun = cc.find("Canvas/beibao/input_cunru").getComponent(cc.EditBox).string;
        var xxjb = cc.find("Canvas/beibao/ccg_bg/xd_jb").getComponent(cc.Label).string;
        if(cun>xxjb||!cun){
            cc.vv.alert.show("提示","请输入正确的数量!");
        }else{
            var data = {
                userid:cc.vv.userMgr.userId,
                coins:cun,
            }
            var self = this;
            var onCreate = function (ret) {
                if (ret.errcode !== 0) {
                    console.log(ret.errmsg);
                }
                else {
                    var beibao = JSON.parse(ret.ret[0].beibao_info);  
                    var c_coins = beibao.c_coins;         
                    var coins = ret.ret[0].coins; 
                    cc.find("Canvas/beibao/ccg_bg/xd_jb").getComponent(cc.Label).string=coins;
                    cc.find("Canvas/beibao/ccg_bg/cc_jb").getComponent(cc.Label).string=c_coins;             
                }
            };
            cc.vv.http.sendRequest("/coins_cun", data, onCreate);
        }
    },
    onClickedQu:function(){
        var cun = cc.find("Canvas/beibao/input_quchu").getComponent(cc.EditBox).string;
        var ccjb = cc.find("Canvas/beibao/ccg_bg/cc_jb").getComponent(cc.Label).string;
        if(cun>ccjb||!cun){
            cc.vv.alert.show("提示","请输入正确的数量!");
        }else{
            var data = {
                userid:cc.vv.userMgr.userId,
                coins:cun,
            }
            var self = this;
            var onCreate = function (ret) {
                if (ret.errcode !== 0) {
                    console.log(ret.errmsg);
                }
                else {
                    var beibao = JSON.parse(ret.ret[0].beibao_info);  
                    var c_coins = beibao.c_coins;         
                    var coins = ret.ret[0].coins; 
                    cc.find("Canvas/beibao/ccg_bg/xd_jb").getComponent(cc.Label).string=coins;
                    cc.find("Canvas/beibao/ccg_bg/cc_jb").getComponent(cc.Label).string=c_coins;             
                }
            };
            cc.vv.http.sendRequest("/coins_qu", data, onCreate);
        }
    },
    onClickJian1:function(){
        var c1 = cc.find("Canvas/beibao/input_cunru").getComponent(cc.EditBox).string;
        cc.find("Canvas/beibao/input_cunru").getComponent(cc.EditBox).string=c1-100>0?c1-100:0;
        var bfb=cc.find("Canvas/beibao/input_cunru").getComponent(cc.EditBox).string/cc.find("Canvas/beibao/ccg_bg/xd_jb").getComponent(cc.Label).string;
        cc.find("Canvas/beibao/cunru/progress").getComponent(cc.Slider).progress = bfb;
    },
    onClickJian:function(){
        var c2 = cc.find("Canvas/beibao/input_quchu").getComponent(cc.EditBox).string;
        cc.find("Canvas/beibao/input_quchu").getComponent(cc.EditBox).string=c2-100>0?c2-100:0;
        cc.find("Canvas/beibao/quchu/progress").getComponent(cc.Slider).progress = bfb;
        
    },
    onClickJia1:function(){
        var q1 = cc.find("Canvas/beibao/input_cunru").getComponent(cc.EditBox).string;
        var xd = cc.find("Canvas/beibao/ccg_bg/xd_jb").getComponent(cc.Label).string;
        cc.find("Canvas/beibao/input_cunru").getComponent(cc.EditBox).string=Math.floor(q1)+100>xd?xd:Math.floor(q1)+100;
        cc.find("Canvas/beibao/cunru/progress").getComponent(cc.Slider).progress = bfb;
        
    },
    onClickJia:function(){
        var q2 = cc.find("Canvas/beibao/input_quchu").getComponent(cc.EditBox).string;
        var xd = cc.find("Canvas/beibao/ccg_bg/xd_jb").getComponent(cc.Label).string;
        cc.find("Canvas/beibao/input_quchu").getComponent(cc.EditBox).string=Math.floor(q2)+100>xd?xd:Math.floor(q2)+100;
        cc.find("Canvas/beibao/quchu/progress").getComponent(cc.Slider).progress = bfb;
        
    },
    onClickDuihuan:function(){
        var label = cc.find("Canvas/beibao/xiangxi_bg/btn_duihuan/label").getComponent(cc.Label).string;
        if(label=="提现"){
            cc.find("Canvas/hongbaotx").active=true;
        }
    },
    // update (dt) {},
});
