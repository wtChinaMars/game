var Global = cc.Class({
    extends: cc.Component,
    statics: {
        isstarted:false,
        netinited:false,
        userguid:0,
        nickname:"",
        money:0,
        lv:0,
        roomId:1,
        account:"",
        pwd:"",
        sxfk:null,
        hallgps:false,
        sex:1,
    },
});
